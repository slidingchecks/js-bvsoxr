<?php
/* Smarty version 3.1.34-dev-7, created on 2019-01-17 09:23:54
  from '/var/www/html/doxbin.org/smarty/templates/default/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5c40ac1a2ae632_91583377',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e748bae1fde97d414fca627451ae3dfff1145665' => 
    array (
      0 => '/var/www/html/doxbin.org/smarty/templates/default/footer.tpl',
      1 => 1547742013,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c40ac1a2ae632_91583377 (Smarty_Internal_Template $_smarty_tpl) {
?>
    <?php echo '<script'; ?>
 src="legacy/jquery.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="legacy/bin.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="legacy/jquery-ui-1.10.3.custom.min.js"><?php echo '</script'; ?>
>
    <?php echo '<script'; ?>
 src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"><?php echo '</script'; ?>
>
</body>
</html><?php }
}
